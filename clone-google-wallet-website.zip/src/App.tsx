import { useState, useEffect } from 'react';
import { IconsMap } from './components/IconsMap';
import { Header, AppPage } from './components/Header';
import { Hero } from './components/Hero';
import { PopularDestinationsPicker } from './components/PopularDestinationsPicker';
import { JumplinksBar } from './components/JumplinksBar';
import { FeatureSection } from './components/FeatureSection';
import { AccessSection } from './components/AccessSection';
import { BottomPromo } from './components/BottomPromo';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { FloatingQRCode } from './components/FloatingQRCode';
import { DownloadModal } from './components/DownloadModal';
import { WalletSimulatorModal } from './components/WalletSimulatorModal';
import { GoogleWalletDashboard } from './components/dashboard/GoogleWalletDashboard';
import { FEATURE_SECTIONS } from './data/walletData';

// Standalone pages
import { AboutPage } from './pages/AboutPage';
import { ServicesPage } from './pages/ServicesPage';
import { CountriesPage } from './pages/CountriesPage';
import { WorkVisaPage } from './pages/WorkVisaPage';
import { BlogPage } from './pages/BlogPage';
import { AppointmentPage } from './pages/AppointmentPage';
import { ContactPage } from './pages/ContactPage';
import { BusinessNetworkPage } from './pages/BusinessNetworkPage';
import { LegalPage } from './pages/LegalPage';

export function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>('home');
  const [isDashboardView, setIsDashboardView] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('payments');
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [selectedCountryForAppointment, setSelectedCountryForAppointment] = useState('United States');

  // Check URL params on initial load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const hash = window.location.hash.replace('#', '');

    if (params.get('view') === 'dashboard' || hash === 'dashboard' || params.get('utm_source') === 'chrome') {
      setIsDashboardView(true);
    } else if (hash && ['about', 'services', 'countries', 'work-visa', 'blog', 'appointment', 'contact', 'business-network', 'legal'].includes(hash)) {
      setCurrentPage(hash as AppPage);
    }
  }, []);

  // Update document title dynamically
  useEffect(() => {
    if (isDashboardView) {
      document.title = 'VisaHOBe Client Portal';
    } else {
      switch (currentPage) {
        case 'about':
          document.title = 'About Us | VisaHOBe - Global Visa Support';
          break;
        case 'services':
          document.title = 'Visa Services & Document Checklists | VisaHOBe';
          break;
        case 'countries':
          document.title = 'Country Visa Guides (US, UK, Schengen) | VisaHOBe';
          break;
        case 'work-visa':
          document.title = 'Work Visa & Skilled Overseas Employment Info | VisaHOBe';
          break;
        case 'blog':
          document.title = 'Visa Guides, Checklists & Refusal Insights | VisaHOBe';
          break;
        case 'appointment':
          document.title = 'Book a Consultation | VisaHOBe';
          break;
        case 'contact':
          document.title = 'Contact & Support Desks | VisaHOBe';
          break;
        case 'business-network':
          document.title = 'B2B Partner Network & Corporate Portal | VisaHOBe';
          break;
        case 'legal':
          document.title = 'Policies, Terms & Consular Disclaimer | VisaHOBe';
          break;
        default:
          document.title = 'VisaHOBe - Your Trusted Partner for Global Visa Support';
      }
    }
  }, [isDashboardView, currentPage]);

  // Scroll spy to highlight active section in Jumplinks bar on Home page
  useEffect(() => {
    if (currentPage !== 'home' || isDashboardView) return;

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 220;

      for (let i = FEATURE_SECTIONS.length - 1; i >= 0; i--) {
        const sec = FEATURE_SECTIONS[i];
        const el = document.getElementById(sec.id);
        if (el) {
          const top = el.offsetTop;
          if (scrollPosition >= top) {
            setActiveSection(sec.id);
            return;
          }
        }
      }

      if (window.scrollY < 600) {
        setActiveSection(FEATURE_SECTIONS[0].id);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [currentPage, isDashboardView]);

  const handleSelectSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -90;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const handleNavigatePage = (page: AppPage) => {
    setIsDashboardView(false);
    setCurrentPage(page);
    window.history.pushState({ page }, '', `#${page === 'home' ? '' : page}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLogin = () => {
    setIsDashboardView(true);
    window.history.pushState({ view: 'dashboard' }, '', '#dashboard');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const handleExitDashboard = () => {
    setIsDashboardView(false);
    window.history.pushState({ page: currentPage }, '', `#${currentPage === 'home' ? '' : currentPage}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateFaq = () => {
    if (currentPage !== 'home') {
      setCurrentPage('home');
      setTimeout(() => {
        const el = document.getElementById('faqs');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById('faqs');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenBooking = (countryName?: string) => {
    if (countryName) {
      setSelectedCountryForAppointment(countryName);
    }
    handleNavigatePage('appointment');
  };

  // Browser history popstate handler
  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash === 'dashboard' || window.location.search.includes('view=dashboard')) {
        setIsDashboardView(true);
      } else {
        setIsDashboardView(false);
        if (['about', 'services', 'countries', 'work-visa', 'blog', 'appointment', 'contact', 'business-network', 'legal'].includes(hash)) {
          setCurrentPage(hash as AppPage);
        } else {
          setCurrentPage('home');
        }
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // View: Client Portal Dashboard
  if (isDashboardView) {
    return (
      <>
        <IconsMap />
        <GoogleWalletDashboard onExit={handleExitDashboard} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f0ec] text-[#3c4043] flex flex-col selection:bg-[#c2e7ff] relative">
      {/* SVG Symbols Definition */}
      <IconsMap />

      {/* Header */}
      <Header
        currentPage={currentPage}
        onNavigatePage={handleNavigatePage}
        onOpenPortal={handleOpenLogin}
        onOpenConsultation={() => handleOpenBooking()}
      />

      {/* Main Content Area */}
      <main id="page-content" className="flex-1">
        {currentPage === 'home' && (
          <>
            {/* Hero Section */}
            <Hero
              onOpenDownload={() => setIsDownloadModalOpen(true)}
              onOpenSimulator={handleOpenLogin}
            />

            {/* Quick Popular Destinations Bar */}
            <PopularDestinationsPicker
              onSelectCountry={() => handleNavigatePage('countries')}
              onViewAllCountries={() => handleNavigatePage('countries')}
            />

            {/* Floating / Sticky Jumplinks Bar */}
            <JumplinksBar
              activeSection={activeSection}
              onSelectSection={handleSelectSection}
            />

            {/* 8 Feature Sections */}
            <div className="space-y-4">
              {FEATURE_SECTIONS.map((section, idx) => (
                <FeatureSection
                  key={section.id}
                  section={section}
                  index={idx}
                />
              ))}
            </div>

            {/* Access Across Google Section */}
            <AccessSection />

            {/* Bottom Call to Action Promo */}
            <BottomPromo
              onOpenDownload={() => setIsDownloadModalOpen(true)}
              onOpenSimulator={handleOpenLogin}
            />

            {/* FAQ Section */}
            <FAQSection />
          </>
        )}

        {currentPage === 'about' && (
          <AboutPage
            onOpenConsultation={() => handleOpenBooking()}
            onOpenPortal={handleOpenLogin}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            onSelectService={() => {}}
            onBookConsultation={() => handleOpenBooking()}
          />
        )}

        {currentPage === 'countries' && (
          <CountriesPage
            onBookConsultation={(country) => handleOpenBooking(country)}
            onOpenPortal={handleOpenLogin}
          />
        )}

        {currentPage === 'work-visa' && (
          <WorkVisaPage
            onBookConsultation={() => handleOpenBooking()}
          />
        )}

        {currentPage === 'blog' && (
          <BlogPage
            onBookConsultation={() => handleOpenBooking()}
          />
        )}

        {currentPage === 'appointment' && (
          <AppointmentPage
            initialCountry={selectedCountryForAppointment}
            onBookingSuccess={() => handleNavigatePage('home')}
          />
        )}

        {currentPage === 'contact' && <ContactPage />}

        {currentPage === 'business-network' && (
          <BusinessNetworkPage
            onOpenPortal={handleOpenLogin}
          />
        )}

        {currentPage === 'legal' && <LegalPage />}
      </main>

      {/* Footer */}
      <Footer
        onNavigatePage={handleNavigatePage}
        onNavigateFaq={handleNavigateFaq}
      />

      {/* Floating Bottom-Right QR Code Widget */}
      <FloatingQRCode onOpenDownloadModal={() => setIsDownloadModalOpen(true)} />

      {/* Floating Pill: Quick Launcher to Client Portal */}
      <div className="fixed bottom-6 left-6 z-40 hidden md:block">
        <button
          type="button"
          onClick={handleOpenLogin}
          className="bg-white/95 hover:bg-white text-neutral-800 text-xs font-semibold px-4 py-2.5 rounded-full shadow-lg border border-black/10 flex items-center gap-2 hover:shadow-xl transition-all hover:scale-105 cursor-pointer"
          title="Open VisaHOBe Client Portal"
        >
          <span className="material-icons text-[#1a73e8] text-base">dashboard</span>
          <span>Log into VisaHOBe Portal</span>
        </button>
      </div>

      {/* Download App QR Code Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Live VisaHOBe Terminal & Pass Simulator Modal */}
      <WalletSimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
      />
    </div>
  );
}

export default App;
